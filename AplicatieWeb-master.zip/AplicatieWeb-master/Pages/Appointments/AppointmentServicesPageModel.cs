﻿namespace AplicatieWeb.Pages.Appointments
{
    public class AppointmentServicesPageModel
    {
    }
}